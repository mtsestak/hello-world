package business.category;

import java.util.List;

/**
 * This interface class declares abstract methods that will be implemented
 * in the CategoryDaoJdbc to retrieve objects from the SQL database
 */
public interface CategoryDao {

    public List<Category> findAll();

    public Category findByCategoryId(long categoryId);

    public Category findByName(String name);

}
