package business.category;

/**
 * The Category class is used to construct Category Objects
 * which are characterized by a name and id number, and
 * correspond with entries in the bookstore's SQL database.
 * Each Book object in the bookstore's database is associated
 * with a Category.
 */
public class Category {

    private long categoryId;
    private String name;

    /**
     * This is a constructor method to create a Category object
     * @param categoryId a long variable that is the Category's id number
     * @param name a String variable that is the Category's name
     */
    public Category(long categoryId, String name) {
        this.categoryId = categoryId;
        this.name = name;
    }

    /**
     * Getter method that returns the Category's id number
     * @return a long variable representing the Category's id number
     */
    public long getCategoryId() {
        return categoryId;
    }

    /**
     * Getter method that returns the Category's name
     * @return a String variable that represents the Category's name
     */
    public String getName() {
        return name;
    }

    /**
     * To String method that returns the Category's characteristics
     * @return a String containing the Category's identifying information
     */
    @Override
    public String toString() {
        return "Category{" +
                "categoryId=" + categoryId +
                ", name='" + name + '\'' +
                '}';
    }
}
