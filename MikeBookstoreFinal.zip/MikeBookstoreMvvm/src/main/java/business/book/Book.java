package business.book;

/**
 *  The Book class is used to construct Book objects.  These objects are
 *  characterized by a number of variables that correspond to Book entries in
 *  the bookstore's SQL database of inventory items.
 */
public class Book {

	private long bookId;
	private String title;
	private String author;
	private int price;
	private boolean isPublic;
	private long categoryId;

	/**
	 * This is a constructor method used to create a book object
	 * @param bookId a long variable that is the book's id number
	 * @param title a String variable that is the book's title
	 * @param author a String variable that is the name of the Book's author
	 * @param price an int variable that is the book's price
	 * @param isPublic a boolean variable that indicates if the book can be read online
	 * @param categoryId a long variable that represents the book's category
	 */
	public Book(long bookId, String title, String author, int price, boolean isPublic, long categoryId) {
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.price = price;
		this.isPublic = isPublic;
		this.categoryId = categoryId;
	}

	/**
	 * Getter method that returns the Book's id number
	 * @return a long variable that is the Book's id number
	 */
	public long getBookId() {
		return bookId;
	}

	/**
	 * Getter method that returns the Book's title
	 * @return a String variable that contains the Book's title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Getter method that returns the Book's author
	 * @return a String variable that contains the Book's author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * Getter method that returns the Book's list price
	 * @return an int varible that is the Book's price
	 */
	public int getPrice() {
		return price;
	}

	/**
	 * Getter method that returns the Book's availability to read online
	 * @return a boolean variable that reflects the Book's online availability
	 */
	public boolean getIsPublic() {
		return isPublic;
	}

	/**
	 * Getter method that returns the Category id number of the Category containing this Book
	 * @return a long variable that is the Category id number
	 */
	public long getCategoryId() {
		return categoryId;
	}

	/**
	 * To String method that returns the Book's characteristics
	 * @return a String containing the Book's identifying information
	 */
	@Override
	public String toString() {
		return "Book{" +
				"bookId=" + bookId +
				", title='" + title + '\'' +
				", author='" + author + '\'' +
				", price=" + price +
				", isPublic=" + isPublic +
				", categoryId=" + categoryId +
				'}';
	}
}
