package business.book;

import java.util.List;

/**
 * This interface class declares abstract methods that will be implemented
 * in the BookDaoJdbc to retrieve objects from the SQL database
 */
public interface BookDao {

    public Book findByBookId(long bookId);

    public List<Book> findByCategoryId(long categoryId);

}
