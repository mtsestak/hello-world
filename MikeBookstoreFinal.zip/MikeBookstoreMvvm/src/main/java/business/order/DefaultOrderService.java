package business.order;

import business.BookstoreDbException;
import business.JdbcUtils;
import business.book.Book;
import business.book.BookDao;
import business.cart.ShoppingCart;
import business.cart.ShoppingCartItem;
import business.customer.Customer;
import business.customer.CustomerDao;
import business.customer.CustomerForm;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * The DefaultOrderService class is used to place and retrieve Orders
 * via the bookstore's SQL database
 */
public class DefaultOrderService implements OrderService {

    private OrderDao orderDao;
    private LineItemDao lineItemDao;
    private CustomerDao customerDao;
    private BookDao bookDao;
    private Random random = new Random();

    /**
     * This method places an Order in the bookstore's SQL database
     * @param form A CustomerForm object representing the order form completed by the Customer
     * @param cart A ShoppingCart object representing the Book objects that the Customer is purchasing
     * @return A long variable representing the CustomerOrderId
     */
    @Override
    public long placeOrder(CustomerForm form, ShoppingCart cart) {

        try (Connection connection = JdbcUtils.getConnection()) {
            return performPlaceOrderTransaction(form.getName(), form.getAddress(), form.getPhone(), form.getEmail(),
                    form.getCcNumber(), form.getCcExpDate(), cart, connection);
        } catch (SQLException e) {
            throw new BookstoreDbException("Error during close connection for customer order", e);
        }
    }

    /**
     * Helper method that returns the OrderDetails associated with a customerOrderId number
     * by retrieving information from the SQL database
     * @param customerOrderId A long variable representing a customerOrderId
     * @return An OrderDetails object constructed from SQL entries
     */
    @Override
    public OrderDetails getOrderDetails(long customerOrderId) {
        Order order = orderDao.findByCustomerOrderId(customerOrderId);
        Customer customer = customerDao.findByCustomerId(order.getCustomerId());
        List<LineItem> lineItems = lineItemDao.findByCustomerOrderId(customerOrderId);
        List<Book> books = lineItems
                .stream()
                .map(lineItem -> bookDao.findByBookId(lineItem.getBookId()))
                .collect(Collectors.toList());

        return new OrderDetails(order, customer, lineItems, books);
    }

    /**
     * Helper method that places the order in the SQL database
     * @param name A String variable that represents the Customer's name
     * @param address A String variable that represents the Customer's address
     * @param phone A String variable that represents the Customer's phone number
     * @param email A String variable that represents the Customer's email address
     * @param ccNumber A String variable that represents the Customer's credit card number
     * @param ccExpDate A Date object that represents the date of the Order
     * @param cart A ShoppingCart object that represents the Customer's purchase
     * @param connection A Connection object used to connect to the database
     * @return
     */
    private long performPlaceOrderTransaction(String name, String address, String phone, String email,
                                              String ccNumber, Date ccExpDate, ShoppingCart cart,
                                              Connection connection) {
        try {
            connection.setAutoCommit(false);

            long customerId = customerDao.create(connection, name, address, phone, email, ccNumber, ccExpDate);
            long customerOrderId = orderDao.create(connection, cart.getSubtotal() + cart.getSurcharge(),
                    generateConfirmationNumber(), customerId);
            for (ShoppingCartItem item : cart.getItems()) {
                lineItemDao.create(connection, customerOrderId, item.getBookId(), item.getQuantity());
            }
            connection.commit();
            return customerOrderId;
        } catch (Exception e) {
            try {
                connection.rollback();
            } catch (SQLException e1) {
                throw new BookstoreDbException("Failed to roll back transaction", e1);
            }
            return 0;
        }
    }

    /**
     * Helper method that generates a random number as the Order's confirmation number
     * @return An int variable representing the confirmation number
     */
    private int generateConfirmationNumber() {
        return random.nextInt(999999999);
    }

    /**
     * Setter method that sets the OrderDao for an Order
     * @param orderDao An OrderDao object
     */
    public void setOrderDao(OrderDao orderDao) {
        this.orderDao = orderDao;
    }

    /**
     * Setter method that sets the LineItemDao for an Order
     * @param lineItemDao A LineItemDao object
     */
    public void setLineItemDao(LineItemDao lineItemDao) {
        this.lineItemDao = lineItemDao;
    }

    /**
     * Setter method that sets the CustomerDao for an Order
     * @param customerDao A CustomerDao object
     */
    public void setCustomerDao(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }

    /**
     * Setter method that sets the BookDao for an Order
     * @param bookDao A BookDao object
     */
    public void setBookDao(BookDao bookDao) {
        this.bookDao = bookDao;
    }

}
