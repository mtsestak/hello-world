package business.order;

import java.sql.Connection;
import java.util.List;

/**
 * This interface class declares abstract methods that will be implemented
 * in the OrderDaoJdbc to retrieve objects from the SQL database
 */
public interface OrderDao {

    public long create(Connection connection, int amount, int confirmationNumber, long customerId);

    public List<Order> findAll();

    public Order findByCustomerOrderId(long customerOrderId);

    public List<Order> findByCustomerId(long customerId);
}
