package business.order;

import business.cart.ShoppingCart;
import business.customer.CustomerForm;

/**
 * This interface class declares abstract methods that will be implemented
 * in the DefaultOrderService to place and retrieve orders to and from the SQL database
 */
public interface OrderService {

    long placeOrder(CustomerForm form, ShoppingCart cart);

    OrderDetails getOrderDetails(long customerOrderId);

}
