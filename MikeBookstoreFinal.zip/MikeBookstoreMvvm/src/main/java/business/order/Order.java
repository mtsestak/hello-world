package business.order;

import java.util.Date;

/**
 * The Order class is used to hold the details related to a successfully-placed
 * book order
 */
public class Order {

    private long customerOrderId;
    private int amount;
    private Date dateCreated;
    private long confirmationNumber;
    private long customerId;

    /**
     * Full constructor method for an Order object
     * @param customerOrderId A long variable representing the order id number
     * @param amount An int variable representing the order cost
     * @param dateCreated A Date object representing the date the order was placed
     * @param confirmationNumber A long variable representing the order's confirmation number
     * @param customerId A long variable representing the id number of the Customer
     */
    public Order(long customerOrderId, int amount, Date dateCreated, long confirmationNumber, long customerId) {
        this.customerOrderId = customerOrderId;
        this.amount = amount;
        this.dateCreated = dateCreated;
        this.confirmationNumber = confirmationNumber;
        this.customerId = customerId;
    }

    /**
     * Getter method that returns the Customer's Order id number
     * @return A long variable representing the Customer's Order id number
     */
    public long getCustomerOrderId() {
        return customerOrderId;
    }

    /**
     * Getter method that returns the cost of the Order
     * @return An int variable that represents the amount of the Order
     */
    public int getAmount() {
        return amount;
    }

    /**
     * Getter method that returns the Date that the order was created
     * @return A Date object that represents the date that the order was created
     */
    public Date getDateCreated() {
        return dateCreated;
    }

    /**
     * Getter method that returns the Order's confirmation number
     * @return A long variable that represents the Order's confirmation number
     */
    public long getConfirmationNumber() {
        return confirmationNumber;
    }

    /**
     * Getter method that returns the Order's Customer id number
     * @return A long variable representing the Order's customer id number
     */
    public long getCustomerId() {
        return customerId;
    }

    /**
     * To String method that returns the Order details
     * @return A String containing the Order details
     */
    @Override
    public String toString() {
        return "Order{" +
                "customerOrderId=" + customerOrderId +
                ", amount=" + amount +
                ", dateCreated=" + dateCreated +
                ", confirmationNumber=" + confirmationNumber +
                ", customerId=" + customerId +
                '}';
    }
}
