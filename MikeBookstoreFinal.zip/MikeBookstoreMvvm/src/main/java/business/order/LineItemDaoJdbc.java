package business.order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static business.JdbcUtils.getConnection;
import business.BookstoreDbException;
import business.BookstoreDbException.BookstoreQueryDbException;
import business.BookstoreDbException.BookstoreUpdateDbException;

/**
 * The LineItemDaoJdbc class is used to retrieve LineItem objects from the
 * bookstore's SQL database
 */
public class LineItemDaoJdbc implements LineItemDao {

    private static final String CREATE_LINE_ITEM_SQL =
            "INSERT INTO customer_order_line_item (customer_order_id, book_id, quantity) " +
                    "VALUES (?, ?, ?)";

    private static final String FIND_BY_CUSTOMER_ORDER_ID_SQL =
            "SELECT customer_order_id, book_id, quantity " +
                    "FROM customer_order_line_item WHERE customer_order_id = ?";

    /**
     * This method creates a LineItem entry into the bookstore's SQL database
     * @param connection A Connection object used to connect to the databasse
     * @param customerOrderId A long variable representing the customer's order id number
     * @param bookId A long variable representing the id number of the Book in the LineItem
     * @param quantity An int variable representing the number of Books in the LineItem
     */
    @Override
    public void create(Connection connection, long customerOrderId, long bookId, int quantity) {
        try (PreparedStatement statement = connection.prepareStatement(CREATE_LINE_ITEM_SQL)) {
            statement.setLong(1, customerOrderId);
            statement.setLong(2, bookId);
            statement.setInt(3, quantity);
            int affected = statement.executeUpdate();
            if (affected != 1) {
                throw new BookstoreUpdateDbException("Failed to insert an order line item, affected row count = " + affected);
            }
            //long lineItemId;
            //ResultSet rs = statement.getGeneratedKeys();
            //if (rs.next()) {
                //lineItemId = rs.getLong(1);
            //} else {
                //throw new BookstoreQueryDbException("Failed to retrieve customerId auto-generated key");
            //}
            //return lineItemId;
        } catch (SQLException e) {
            throw new BookstoreQueryDbException("Encountered problem creating a new line item ", e);
        }
    }

    /**
     * This method finds the LineItems in the SQL database associated with a customerOrderId number
     * @param customerOrderId a long variable representing the id number to use in the search
     * @return a List of LineItem objects associated with the customerOrderId parameter
     */
    @Override
    public List<LineItem> findByCustomerOrderId(long customerOrderId) {
        List<LineItem> result = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_BY_CUSTOMER_ORDER_ID_SQL)) {
            statement.setLong(1, customerOrderId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    result.add(readLineItem(resultSet));
                }
            }
        } catch (SQLException e) {
            throw new BookstoreQueryDbException("Encountered problem finding ordered books for customer order "
                    + customerOrderId, e);
        }
        return result;
    }

    /**
     * This helper method utilizes the SQL search results to construct a
     * LineItem object, which is then passed to the method that called it
     * @param resultSet the ResultSet of the SQL query
     * @return a LineItem object identified by the SQL query
     * @throws SQLException when the SQL search results in an exception
     */
    private LineItem readLineItem(ResultSet resultSet) throws SQLException {
        long customerOrderId = resultSet.getLong("customer_order_id");
        long bookId = resultSet.getLong("book_id");
        int quantity = resultSet.getInt("quantity");
        return new LineItem(customerOrderId, bookId, quantity);
    }
}
