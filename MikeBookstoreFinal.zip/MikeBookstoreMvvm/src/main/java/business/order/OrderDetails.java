package business.order;

import business.book.Book;
import business.customer.Customer;

import java.util.Collections;
import java.util.List;

/**
 * The OrderDetails class holds details about an Order placed
 * by a Customer, to include a List of the LineItems and Books
 * that comprise the Order
 */
public class OrderDetails {

    private Order order;
    private Customer customer;
    private List<LineItem> lineItems;
    private List<Book> books;

    /**
     * Full constructor for an OrderDetails object
     * @param order An Order object placed by the Customer
     * @param customer A Customer object who placed the order
     * @param lineItems A List of the LineItems that comprise the Order
     * @param books A List of Book objects contained in the Order
     */
    public OrderDetails(Order order, Customer customer,
                        List<LineItem> lineItems, List<Book> books) {
        this.order = order;
        this.customer = customer;
        this.lineItems = lineItems;
        this.books = books;
    }

    /**
     * Getter method that returns the Order object that is the subject of
     * the OrderDetails object
     * @return The Order object
     */
    public Order getOrder() {
        return order;
    }

    /**
     * Getter method that returns the Customer who placed the Order
     * @return A Customer object who placed the order
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * Getter method that returns a List of Book objects contained in the Order
     * @return A List of Book objects
     */
    public List<Book> getBooks() {
        return Collections.unmodifiableList(books);
    }

    /**
     * Getter method that returns a List of LineItems contained in the Order
     * @return A List of LineItems objects
     */
    public List<LineItem> getLineItems() {
        return Collections.unmodifiableList(lineItems);
    }
}
