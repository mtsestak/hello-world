package business.order;

import java.sql.Connection;
import java.util.List;

/**
 * This interface class declares abstract methods that will be implemented
 * in the LineItemDaoJdbc to retrieve objects from the SQL database
 */
public interface LineItemDao {

    public void create(Connection connection, long customerOrderId, long bookId, int quantity);

    public List<LineItem> findByCustomerOrderId(long customerOrderId);
}
