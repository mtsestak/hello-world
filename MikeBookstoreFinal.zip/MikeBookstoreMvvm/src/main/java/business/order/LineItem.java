package business.order;

/**
 * The LineItem class is used to construct individual LineItems that
 * will comprise a Customer Order
 */
public class LineItem {

    private long bookId;
    private long customerOrderId;
    private int quantity;

    /**
     * This is a constructor method that creates a LineItem
     * @param customerOrderId A long variable representing the Customer Order's id number
     * @param bookId A long variable representing a Book's id number
     * @param quantity An int variable representing the quantity of Books ordered
     */
    public LineItem( long customerOrderId, long bookId, int quantity) {
        this.customerOrderId = customerOrderId;
        this.bookId = bookId;
        this.quantity = quantity;
    }

    /**
     * Getter method that returns a Book's id number
     * @return A long variable representing the Book's id number
     */
    public long getBookId() {
        return bookId;
    }

    /**
     * Getter method that returns a Customer Order's id number
     * @return A long variable representing the Customer Order's id number
     */
    public long getCustomerOrderId() {
        return customerOrderId;
    }

    /**
     * Getter method that returns the quantity of Books ordered in the LineItem
     * @return An int variable representing the quantity of Books ordered
     */
    public int getQuantity() { return quantity; }

    /**
     * To String method used to return a LineItems details
     * @return A string containing the LineItem's details
     */
    @Override
    public String toString() {
        return "LineItem{" +
                "customerOrderId=" + customerOrderId  +
                ", bookId=" + bookId +
                ", quantity=" + quantity +
                '}';
    }
}