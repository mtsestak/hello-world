package business.customer;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

/**
 * The CustomerForm class is used to create a form holding the Customer's
 * information.  The Customer completes this form during the checkout
 * process and utilizes client and server side validation to ensure that
 * the information provided is within defined parameters
 */
public class CustomerForm {

    private String name;
    private String address;
    private String phone;
    private String email;
    private String ccNumber;
    private String ccMonth;
    private String ccYear;
    private Date ccExpDate;

    private boolean hasNameError;
    private boolean hasAddressError;
    private boolean hasPhoneError;
    private boolean hasEmailError;
    private boolean hasCreditCardError;
    private boolean hasCcExpDateError;

    /**
     * Empty constructor method for a CustomerForm object
     */
    public CustomerForm() {
        this("","","","","",
                String.valueOf(Calendar.getInstance().get(Calendar.MONTH)+1),
                String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));
    }

    /**
     * Full constructor method for a CustomerForm object
     * @param name A String variable that represents the Customer name field input
     * @param address A String variable that represents the Customer address field input
     * @param phone A String variable that represents the Customer phone number field input
     * @param email A String variable that represents the Customer email address field input
     * @param ccNumber A String variable that represents the Customer credit card number field input
     * @param ccMonth A String variable that represents the credit card's expiration month field input
     * @param ccYear A String variable that represents the credit card's expiration year field input
     */
    public CustomerForm(String name, String address, String phone, String email, String ccNumber, String ccMonth,
                        String ccYear) {
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.ccNumber = ccNumber;
        this.ccMonth = ccMonth;
        this.ccYear = ccYear;
        this.ccExpDate = getCcExpDate(ccMonth, ccYear);
        validate();
    }

    /**
     * Getter method for the Customer name field
     * @return A String variable representing the Customer name field input
     */
    public String getName() {
        return name;
    }

    /**
     * Getter method for the Customer address field
     * @return A String variable representing the Customer address field input
     */
    public String getAddress() {
        return address;
    }

    /**
     * Getter method for the Customer phone number field
     * @return A String variable representing the Customer phone number field input
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Getter method for the Customer email address field
     * @return A String variable representing the Customer email address field input
     */
    public String getEmail() {
        return email;
    }

    /**
     * Getter method for the Customer credit card number field
     * @return A String variable representing the Customer credit card number field input
     */
    public String getCcNumber() {
        return ccNumber;
    }

    /**
     * Getter method for the credit card's expiration month field
     * @return A String variable representing the credit card's expiration month field input
     */
    public String getCcMonth() { return ccMonth;}

    /**
     * Getter method for the credit card's expiration year field
     * @return A String variable representing the credit card's expiration year field input
     */
    public String getCcYear() { return ccYear;}

    /**
     * Getter method for the credit card's expiration Date
     * @return A Date object representing the credit card's expiration date
     */
    public Date getCcExpDate() {
        return ccExpDate;
    }

    /**
     * Getter method that returns a value indicating if the input entered into the CustomerForm's
     * name field is outside of the defined parameters
     * @return A boolean variable that indicates if the name field is outside of defined parameters
     */
    public boolean getHasNameError() {
        return hasNameError;
    }

    /**
     * Getter method that returns a value indicating if the input entered into the CustomerForm's
     * address field is outside of the defined parameters
     * @return A boolean variable that indicates if the address field is outside of defined parameters
     */
    public boolean getHasAddressError() {
        return hasAddressError;
    }

    /**
     * Getter method that returns a value indicating if the input entered into the CustomerForm's
     * phone number field is outside of the defined parameters
     * @return A boolean variable that indicates if the phone number field is outside of defined parameters
     */
    public boolean getHasPhoneError() {
        return hasPhoneError;
    }

    /**
     * Getter method that returns a value indicating if the input entered into the CustomerForm's
     * email address field is outside of the defined parameters
     * @return A boolean variable that indicates if the email address field is outside of defined parameters
     */
    public boolean getHasEmailError() {
        return hasEmailError;
    }

    /**
     * Getter method that returns a value indicating if the input entered into the CustomerForm's
     * credit card number field is outside of the defined parameters
     * @return A boolean variable that indicates if the credit card number field is outside of defined parameters
     */
    public boolean getHasCreditCardError() {
        return hasCreditCardError;
    }

    /**
     * Getter method that returns a value indicating if the input entered into the CustomerForm's
     * credit card expiration date field is outside of the defined parameters
     * @return A boolean variable that indicates if the credit card expiration date is outside of defined parameters
     */
    public boolean getHasCcExpDateError() {
        return hasCcExpDateError;
    }

    /**
     * Getter method that returns a value indicating if the input entered into any one of the CustomerForm's
     * fields is outside of the defined parameters
     * @return A boolean variable that indicates if a CustomerForm field's input is outside of defined parameters
     */
    public boolean getHasFieldError() {
        return (hasNameError || hasAddressError || hasPhoneError || hasEmailError || hasCreditCardError
                || hasCcExpDateError);
    }

    /**
     * Getter method that returns an error message associated with the Customer name field
     * @return A String constituting an error message
     */
    public String getNameErrorMessage() {
        return "Valid name required (ex: John Smith)";
    }

    /**
     * Getter method that returns an error message associated with the Customer address field
     * @return A String constituting an error message
     */
    public String getAddressErrorMessage() {
        return "Valid address required (ex: 1 Main St)";
    }

    /**
     * Getter method that returns an error message associated with the Customer phone number field
     * @return A String constituting an error message
     */
    public String getPhoneErrorMessage() {
        return "Valid U.S. phone number required (ex: 212-123-4567)";
    }

    /**
     * Getter method that returns an error message associated with the Customer email address field
     * @return A String constituting an error message
     */
    public String getEmailErrorMessage() {
        return "Valid email address required (ex: John@thesmiths.com)";
    }

    /**
     * Getter method that returns an error message associated with the Customer credit card number field
     * @return A String constituting an error message
     */
    public String getCreditCardErrorMessage() {
        return "Valid credit card number required between 14-16 digits";
    }

    /**
     * Getter method that returns an error message associated with the credit card expiration date field
     * @return A String constituting an error message
     */
    public String getCcExpDateErrorMessage() {
        return "Valid credit card expiration date required (i.e. must be after today's date)";
    }

    /**
     * Helper method that checks CustomerForm field input against the acceptable parameters defined
     * within this method
     */
    private void validate() {
        if (name == null || name.equals("") || name.length() > 45) {
            hasNameError = true;
        }
        if (address == null || address.equals("") || address.length() > 45) {
            hasAddressError = true;
        }
        if (phone == null || phone.equals("") || phone.length() > 20) {
            hasPhoneError = true;
        }
        else {
            String phoneNumber = phone.replaceAll("[-()\\s]", "");
            if (phoneNumber.length() != 10) {
                hasPhoneError = true;
            }
        }
        if (email == null || email.equals("") || email.contains(" ") || !email.contains("@")) {
            hasEmailError = true;
        }
        else {
            String validEmail = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
            if (!email.matches(validEmail)) {
                hasEmailError = true;
            }
        }
        if (ccNumber == null || ccNumber.equals("")) {
            hasCreditCardError = true;
        }
        else {
            String ccNum = ccNumber.replaceAll("[\\s-]", "");
            if (ccNum.length() < 14 || ccNum.length() > 16) {
                hasCreditCardError = true;
            }
        }
        if (ccExpDate == null || ccExpDate.before(new Date())) {
          hasCcExpDateError = true;
        }
    }

    /**
     * Helper method that accepts the String input from the CustomerForm and
     * constructs a Date object representing the credit card's expiration date
     * @param monthString A String variable representing the credit card's expiration month
     * @param yearString A String variable representing the credit card's expiration year
     * @return A Date object formed from the parameters passed into the method
     */
    private Date getCcExpDate(String monthString, String yearString) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        int month = Integer.parseInt(monthString);
        int year = Integer.parseInt(yearString);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.YEAR, year);
        ccExpDate = calendar.getTime();
        return ccExpDate;
    }
}
