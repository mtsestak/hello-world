package business.customer;

import java.sql.Connection;
import java.util.Date;
import java.util.List;

/**
 * This interface class declares abstract methods that will be implemented
 * in the CustomerDaoJdbc to retrieve objects from the SQL database
 */
public interface CustomerDao {

    public long create(Connection connection,
                       String customerName,
                       String address,
                       String phone,
                       String email,
                       String ccNumber,
                       Date ccExpDate);

    public List<Customer> findAll();

    public Customer findByCustomerId(long customerId);

}
