package business.customer;

import java.util.Date;

/**
 * The Customer class is used to construct Customer objects, which are characterized
 * by a number of variables containing bookstore Customer attributes.  These objects
 * are primarily utilized during the order placement process
 */
public class Customer {

    private long customerId;
    private String customerName;
    private String address;
    private String phone;
    private String email;
    private String ccNumber;
    private Date ccExpDate;

    /**
     * The constructor method used to create a Customer object
     * @param customerId a long variable representing the Customer id
     * @param customerName a String variable representing the Customer name
     * @param address A String variable representing the Customer address
     * @param phone A String variable representing the Customer phone
     * @param email a String variable representing the Customer email
     * @param ccNumber a String variable representing the Customer's credit card number
     * @param ccExpDate a Date object representing the expiration date of the Customer's credit card
     */
    public Customer(long customerId, String customerName, String address, String phone, String email, String ccNumber, Date ccExpDate) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.ccNumber = ccNumber;
        this.ccExpDate = ccExpDate;
    }

    /**
     * Getter method that returns the Customer's id number
     * @return a long variable representing the Customer's id number
     */
    public long getCustomerId() {
        return customerId;
    }

    /**
     * Getter method that returns the Customer's name
     * @return a String variable representing the Customer's name
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * Getter method that returns the Customer's address
     * @return a String variable representing the Customer's address
     */
    public String getAddress() { return address; }

    /**
     * Getter method that returns the Customer's phone number
     * @return a String variable representing the Customer's phone number
     */
    public String getPhone() { return phone; }

    /**
     * Getter method that returns the Customer's email
     * @return a String variable representing the Customer's email
     */
    public String getEmail() { return email; }

    /**
     * Getter method that returns the Customer's credit card number
     * @return a String variable representing the Customer's credit card number
     */
    public String getCcNumber() { return ccNumber; }

    /**
     * Getter method that returns the expiration date of the Customer's credit card
     * @return a Date object representing the expiration date
     */
    public Date getCcExpDate() { return ccExpDate; }

    /**
     * To String method that returns the Customer's characteristics
     * @return a String containing the Customer's identifying information
     */
    @Override
    public String toString() {
        return "Customer{" +
                "customerId=" + customerId +
                ", customerName='" + customerName + '\'' +
                ", address='" + address + '\'' +
                ", phone='" + phone + '\'' +
                ", email='" + email + '\'' +
                ", ccNumber='" + ccNumber + '\'' +
                ", ccExpDate=" + ccExpDate +
                '}';
    }
}
