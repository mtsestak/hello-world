package business.customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import business.BookstoreDbException.BookstoreQueryDbException;
import business.BookstoreDbException.BookstoreUpdateDbException;

import static business.JdbcUtils.getConnection;

/**
 * The CustomerDaoJdbc class is used to retrieve Customer objects from the
 * bookstore's SQL database
 */
public class CustomerDaoJdbc implements CustomerDao {

    private static final String CREATE_CUSTOMER_SQL =
            "INSERT INTO `customer` (name, address, phone, email, cc_number, cc_exp_date) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";

    private static final String FIND_ALL_SQL =
            "SELECT customer_id, name, address, " +
                    "phone, email, cc_number, cc_exp_date " +
                    "FROM customer";

    private static final String FIND_BY_CUSTOMER_ID_SQL =
            "SELECT customer_id, name, address, " +
                    "phone, email, cc_number, cc_exp_date " +
                    "FROM customer WHERE customer_id = ?";

    /**
     * This method creates a Customer entry in the bookstore's SQL database and
     * returns the newly-created Customer's id number
     * @param connection A Connection object used to connect to the databasse
     * @param name A String variable representing the Customer's name
     * @param address A String variable representing the Customer's address
     * @param phone A String variable representing the Customer's phone number
     * @param email A String variable representing the Customer's email address
     * @param ccNumber A String variable representing the Customer's credit card number
     * @param ccExpDate A String variable representing the expiration date of the credit card
     * @return a long variable representing the Customer's id number
     */
    @Override
    public long create(Connection connection,
                       String name,
                       String address,
                       String phone,
                       String email,
                       String ccNumber,
                       Date ccExpDate) {
        try (PreparedStatement statement =
                     connection.prepareStatement(CREATE_CUSTOMER_SQL, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, name);
            statement.setString(2, address);
            statement.setString(3, phone);
            statement.setString(4, email);
            statement.setString(5, ccNumber);
            statement.setDate(6, new java.sql.Date(ccExpDate.getTime()));
            int affected = statement.executeUpdate();
            if (affected != 1) {
                throw new BookstoreUpdateDbException("Failed to insert a customer, affected row count = " + affected);
            }
            long customerId;
            ResultSet rs = statement.getGeneratedKeys();
            if (rs.next()) {
                customerId = rs.getLong(1);
            } else {
                throw new BookstoreQueryDbException("Failed to retrieve customerId auto-generated key");
            }
            return customerId;
        } catch (SQLException e) {
            throw new BookstoreUpdateDbException("Encountered problem creating a new customer ", e);
        }

    }

    /**
     * This method finds a List of all Customers contained
     * in the SQL database
     * @return a List of Customer objects
     */
    @Override
    public List<Customer> findAll() {
        List<Customer> result = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_ALL_SQL);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Customer c = readCustomer(resultSet);
                result.add(c);
            }
        } catch (SQLException e) {
            throw new BookstoreQueryDbException("Encountered problem finding all categories", e);
        }

        return result;

    }

    /**
     * This method finds a Customer in the SQL database via its customerId number
     * @param customerId a long variable representing the id number to use in the search
     * @return a Customer object associated with the customerId parameter
     */
    @Override
    public Customer findByCustomerId(long customerId) {

        Customer result = null;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_BY_CUSTOMER_ID_SQL)) {
            statement.setLong(1, customerId);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    result = readCustomer(resultSet);
                }
            }
        } catch (SQLException e) {
            throw new BookstoreQueryDbException("Encountered problem finding customer " + customerId, e);
        }
        return result;
    }

    /**
     * This helper method utilizes the SQL search results to construct a
     * Customer object, which is then passed to the method that called it
     * @param resultSet the ResultSet of the SQL query
     * @return a Customer object identified by the SQL query
     * @throws SQLException when the SQL search results in an exception
     */
    private Customer readCustomer(ResultSet resultSet) throws SQLException {
        Long customerId = resultSet.getLong("customer_id");
        String name = resultSet.getString("name");
        String address = resultSet.getString("address");
        String phone = resultSet.getString("phone");
        String email = resultSet.getString("email");
        String ccNumber = resultSet.getString("cc_number");
        Date ccExpDate = resultSet.getDate("cc_exp_date");
        return new Customer(customerId, name, address, phone, email, ccNumber, ccExpDate);
    }
}
