package business;

/**
 * The BookStoreDbException class extends the RuntimeException class
 * and is used to throw exceptions related to accessing the
 * bookstore's SQL database
 */
public class BookstoreDbException extends RuntimeException {

    /**
     * Single parameter constructor for a BookstoreDbException object
     * @param message A String variable representing the error message
     */
    public BookstoreDbException(String message) {
        super(message);
    }

    /**
     * Full constructor for a BookstoreDbException object
     * @param message A String variable representing the error message
     * @param cause A Throwable object representing the reason for the error
     */
    public BookstoreDbException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructor method for BookstoreConnectionDbException used when the
     * BookstoreDbException is related to a connection issue
     */
    public static class BookstoreConnectionDbException extends BookstoreDbException {
        public BookstoreConnectionDbException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    /**
     * Constructor method for BookstoreQueryDbException used when the
     * BookstoreDbException is related to a database query issue
     */
    public static class BookstoreQueryDbException extends BookstoreDbException {
        public BookstoreQueryDbException(String message) {
            super(message);
        }

        public BookstoreQueryDbException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    /**
     * Constructor method for BookstoreUpdateDbException used when the
     * BookstoreDbException is related to a database update issue
     */
    public static class BookstoreUpdateDbException extends BookstoreDbException {
        public BookstoreUpdateDbException(String message) {
            super(message);
        }

        public BookstoreUpdateDbException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
