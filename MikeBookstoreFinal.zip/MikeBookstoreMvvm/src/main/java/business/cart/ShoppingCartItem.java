package business.cart;
import business.book.Book;

/**
 * The ShoppingCartItem class is used to store the items contained in the
 * users ShoppingCart.  Each item is composed of a Book object and the
 * quantity of each Book object contained within the ShoppingCart
 */
public class ShoppingCartItem {
    private Book book;
    private int quantity;

    /**
     * The constructor for a ShoppingCartItem
     * @param book a Book object to be added to the ShoppingCart
     */
    public ShoppingCartItem(Book book) {
        this.book = book;
        quantity = 1;
    }

    /**
     * Getter method that returns a Book's id number
     * @return a long variable representing the Book's id number
     */
    public long getBookId() {
        return book.getBookId();
    }

    /**
     * Getter method that returns a Book's price
     * @return an int variable that represents the Book's price
     */
    public int getPrice() {
        return book.getPrice();
    }

    /**
     * Getter method that returns the quantity of Book objects
     * in a ShoppingCartItem
     * @return an int variable representing the quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Getter method that returns the total price of the ShoppingCartItem
     * by multiplying the Book object's price by the number of Books
     * @return an int variable representing the total price of the ShoppingCartItem
     */
    public int getTotal() {
        return quantity * getPrice();
    }

    /**
     * Getter method that returns the Book object within a ShoppingCartItem
     * @return the Book object contained within a ShoppingCartItem
     */
    public Book getBook() {
        return book;
    }

    /**
     * Setter method used to set a ShoppingCartItem's quantity
     * @param quantity an int variable representing the quanity's new value
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * Setter method that increments a ShoppingCartItem's quantity by one
     */
    public void incQuantity() { this.quantity++; }

    /**
     * Setter method that decreases a ShoppingCartItem's quantity by one
     */
    public void decQuantity() { this.quantity--; }

    /**
     * Helper method that checks to see if a specified Book object matches
     * the Book object contained in the ShoppingCartItem
     * @param book the Book object to be used in the comparison
     * @return a boolean variable representing the results of the comparison
     */
    public boolean hasBook(Book book) {
        return this.getBookId() == book.getBookId();
    }

    /**
     * Helper method used to compare ShoppingCartItems
     * @param o the Object to be compared
     * @return a boolean variable representing the results of the comparison
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null) return false;
        if (!(o instanceof ShoppingCartItem)) return false;
        ShoppingCartItem that = (ShoppingCartItem) o;
        return this.getBookId() == that.getBookId();
    }
}
