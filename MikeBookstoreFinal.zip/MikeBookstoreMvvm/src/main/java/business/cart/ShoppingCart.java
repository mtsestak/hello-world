package business.cart;
import business.book.Book;
import business.category.Category;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * The Shopping Cart class is used to construct Shopping Cart objects and
 * add or remove Book objects to its contents as the user selects from
 * the options available on the bookstore's website.
 */
public class ShoppingCart {
    public final int maxQuantity = 10;
    List<ShoppingCartItem> items;
    public int surcharge;
    public ShoppingCart() {
        items = new ArrayList<ShoppingCartItem>();
    }

    /**
     * Adds an item (book + quantity) to the cart.
     * If the book is already in the cart, increments
     * the quantity.
     *
     * @param book a Book object to be added to the Shopping Cart
     */
    public synchronized void addItem(Book book) {
        if (bookInCart(book)) {
            increment(book);
        } else {
            ShoppingCartItem item = new ShoppingCartItem(book);
            items.add(item);
        }
    }
    /**
     * Updates the item to the specified quantity.
     * If the quantity is 0 the book is removed.
     * The cart is unchanged if:
     * - the quantity is less than 0
     * - the quantity is greater than the max
     * - the book is not in the cart
     *
     * @param book the Book object whose quantity is to be updated
     * @param quantity an int variable representing the desired quantity of Book objects
     */
    public synchronized void update(Book book , int quantity) {
        ShoppingCartItem item = findItem(book);
        if (item == null || quantity < 0 || quantity > maxQuantity) {
            return;
        }
        if (quantity == 0) {
            items.remove(item);
        } else {
            item.setQuantity(quantity);
        }
    }

    /**
     * Increments the quantity of the item with the book.
     *
     * @param book the Book object whose quantity is to be increased
     */
    public synchronized void increment(Book book) {
        ShoppingCartItem item = findItem(book);
        if (item == null || item.getQuantity() == maxQuantity) {
            return;
        }
        item.setQuantity(item.getQuantity() + 1);
    }

    /**
     * Decrements the quantity of the item with the book.
     *
     * @param book the Book object whose quantity is to be decreased
     */
    public synchronized void decrement(Book book) {
        ShoppingCartItem item = findItem(book);
        if (item == null || item.getQuantity() == 0) {
            return;
        }
        if (item.getQuantity() == 1) {
            items.remove(item);
        } else {
            item.setQuantity(item.getQuantity() - 1);
        }
    }

    /**
     * Returns the list of items.
     *
     * @return a List of ShoppingCartItems representing the contents of the ShoppingCart
     */
    public synchronized List<ShoppingCartItem> getItems() {
        return items;
    }

    /**
     * Returns the sum of quantities for all items in the cart.
     *
     * @return an int variable representing the number of items in the ShoppingCart
     */
    public synchronized int getNumberOfItems() {
        return items.stream()
                .mapToInt(ShoppingCartItem::getQuantity)
                .sum();
    }

    /**
     * Returns the sum of the book price multiplied by the quantity for all
     * items in shopping cart list. This is the total cost *in cents*,
     * not including the surcharge.
     *
     * @return an int variable representing the total price of the Books in the ShoppingCart
     */
    public synchronized int getSubtotal() {
        return items.stream()
                .mapToInt(item -> item.getQuantity() * item.getPrice())
                .sum();
    }

    /**
     * Empties the shopping cart.
     */
    public synchronized void clear() {
        items.clear();
    }

    /**
     * This helper method checks to see if a Book object is already contained
     * in the Shoppingcart
     * @param book the Book object to search for in the ShoppingCart
     * @return a boolean variable indicating if the Book object parameter is present
     */
    private boolean bookInCart(Book book) {
        return items.stream().anyMatch(item -> item.hasBook(book));
    }

    /**
     * This helper method searches for a Book object that is already
     * contained in the ShoppingCart
     * @param book the Book object to search for in the ShoppingCart
     * @return a ShoppingCart item containing the Book object parameter
     */
    private ShoppingCartItem findItem(Book book) {
        Optional<ShoppingCartItem> optItem = items.stream()
                .filter(item -> item.hasBook(book))
                .findFirst();
        return optItem.orElse(null);
    }

    /**
     * Getter method that returns the surcharge used in the shopping transaction
     * @return an int variable representing the surcharge
     */
    public int getSurcharge() { return surcharge;}

    /**
     * Setter method that sets the surcharge to be used in the shopping transaction
     * @param i an int variable representing the surcharge to be applied
     */
    public void setSurcharge(int i) {surcharge = i; }
}