
package business;

import business.category.CategoryDao;
import business.category.CategoryDaoJdbc;
import business.book.BookDao;
import business.book.BookDaoJdbc;
import business.customer.CustomerDao;
import business.customer.CustomerDaoJdbc;
import business.order.*;

/**
 * The ApplicationContext class sets the interfaces that will
 * be used by the application to send and retrieve information
 * to and from the bookstore's SQL database
 */
public class ApplicationContext {

    private CategoryDao categoryDao;
    private BookDao bookDao;
    private CustomerDao customerDao;
    private OrderDao orderDao;
    private LineItemDao lineItemDao;
    private OrderService orderService;

    public static ApplicationContext INSTANCE = new ApplicationContext();

    /**
     * The constructor method for an ApplicationContext object
     */
    private ApplicationContext() {
        categoryDao = new CategoryDaoJdbc();
        bookDao = new BookDaoJdbc();
        customerDao = new CustomerDaoJdbc();
        orderDao = new OrderDaoJdbc();
        lineItemDao = new LineItemDaoJdbc();
        orderService = new DefaultOrderService();
        DefaultOrderService service = (DefaultOrderService) orderService;
        service.setBookDao(bookDao);
        service.setCustomerDao(customerDao);
        service.setOrderDao(orderDao);
        service.setLineItemDao(lineItemDao);

    }

    /**
     * Getter method that returns the ApplicationContext's CategoryDao object
     * @return a CategoryDao object
     */
    public CategoryDao getCategoryDao() {
        return categoryDao;
    }

    /**
     * Getter method that returns the ApplicationContext's BookDao object
     * @return a BookDao object
     */
    public BookDao getBookDao () {
        return bookDao;
    }

    /**
     * Getter method that returns the ApplicationContext's CustomerDao object
     * @return a CustomerDao object
     */
    public CustomerDao getCustomerDao() {return customerDao; }

    /**
     * Getter method that returns the ApplicationContext's OrderDao object
     * @return a OrderDao object
     */
    public OrderDao getOrderDao() {return orderDao; }

    /**
     * Getter method that returns the ApplicationContext's LineItemDao object
     * @return a LineItemDao object
     */
    public LineItemDao lineItemDao() {return lineItemDao; }

    /**
     * Getter method that returns the ApplicationContext's OrderServiceDao object
     * @return a OrderServiceDao object
     */
    public OrderService getOrderService () {return orderService; }
}
