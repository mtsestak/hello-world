package viewmodel;

import business.book.Book;
import business.category.Category;
import business.customer.CustomerForm;
import business.order.*;

import javax.servlet.http.HttpServletRequest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 *  This class establishes the view model that defines the variables
 *  and methods used to select and display objects in the dynamic Confirmation page
 *  it extends the default BaseViewModel
 */
public class ConfirmationViewModel extends BaseViewModel {

    // the Confirmation page needs access to the following variables
    private Category selectedCategory;
    private CustomerForm customerForm;
    private List<LineItem> lineItems;
    private long confirmationNumber;
    private String dateCreated;
    private int amount;

    /**
     * Constructor method for the Confirmation Page
     * @param request an HttpServletRequest object
     */
    public ConfirmationViewModel(HttpServletRequest request) {
        super(request);

        // this line prevents the nav bar from highlighting the home icon as the selected category
        this.selectedCategory = new Category(4, "confirmation");

        this.customerForm = (CustomerForm) session.getAttribute("customerForm");
        OrderDetails orderDetails = (OrderDetails) session.getAttribute("orderDetails");
        this.lineItems = orderDetails.getLineItems();
        this.confirmationNumber = orderDetails.getOrder().getConfirmationNumber();
        DateFormat orderDate = new SimpleDateFormat("MMMMMMMMM dd, yyyy  h:mm a z");
        dateCreated = orderDate.format(orderDetails.getOrder().getDateCreated());
        this.amount = orderDetails.getOrder().getAmount();
    }

    /**
     * Getter method that returns a Book object based on the bookId attribute
     * @param l a long variable representing a bookId
     * @return a Book object with a bookId matching the parameter
     */
    public Book getBook(long l) {
        return bookDao.findByBookId(l);
    }

    /**
     * Getter method that returns the selected Category
     * @return a Category object
     */
    public Category getSelectedCategory() {
        return selectedCategory;
    }

    /**
     * Getter method that returns the user's CustomerForm
     * @return a CustomerForm object
     */
    public CustomerForm getCustomerForm() {
        return customerForm;
    }

    /**
     * Getter method that returns a List of LineItems from a user's Order
     * @return a List of LineItem objects
     */
    public List<LineItem> getLineItems() { return lineItems; }

    /**
     * Getter method that returns the user's confirmation number for a placed Order
     * @return a long variable representing the confirmation number
     */
    public long getConfirmationNumber() { return confirmationNumber; }

    /**
     * Getter method that returns the date the user's Order was placed
     * @return a String variable representing the Order date
     */
    public String getDateCreated () { return dateCreated; }

    /**
     * Getter method that returns the total cost of the user's Order
     * @return an int variable representing the Order amount
     */
    public int getAmount() { return amount; }
}