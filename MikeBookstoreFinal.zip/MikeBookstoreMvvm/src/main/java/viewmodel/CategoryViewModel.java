package viewmodel;

import business.book.Book;
import business.category.Category;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 *  This class establishes the view model that defines the variables
 *  and methods used to select and display objects in the dynamic Category pages
 *  it extends the default BaseViewModel
 */
public class CategoryViewModel extends BaseViewModel {

    // each cetegory page needs to know the selected Category and a list of the
    // Categories available on the bookstore site
    private Category selectedCategory;
    private List<Book> selectedCategoryBooks;

    /**
     * Constructor method for the Category page that identifies the selected Category
     * and the Book objects within that Category
     * @param request an HttpServletRequest object
     */
    public CategoryViewModel(HttpServletRequest request) {
        super(request);
        // the following if/else if series resolves an issue related to my
        // decision to utilize the '&' character in th bookstore category names
        // stored in the SQL database
        String categoryName = request.getParameter("category");
        if (categoryName.contains("business")) {
            categoryName = "business_&_finance";
        }
        else if (categoryName.contains("fiction")) {
            categoryName = "fiction_&_literature";
        }
        else if (categoryName.contains("mystery")) {
            categoryName = "mystery_&_romance";
        }
        else if (categoryName.contains("sci-fi")) {
            categoryName = "sci-fi_&_fantasy";
        }
        else if (categoryName.contains("textbooks")) {
            categoryName = "textbooks_&_reference";
        }
        selectedCategory = (isValidName(categoryName)) ?
                categoryDao.findByName(categoryName) :
                categoryDao.findByCategoryId(1001);
        selectedCategoryBooks = bookDao.findByCategoryId(selectedCategory.getCategoryId());
    }

    /**
     * Helper method that checks the validity of the Category name
     * @param name a String variable representing the selected Category name
     * @return a boolean variable representing the validity of the name parameter
     */
    private boolean isValidName (String name) {
        if (name==null || categoryDao.findByName(name)==null) {
            return false;
        }
        return true;
    }

    /**
     *
     * @return
     */
    public Category getSelectedCategory() {
            return selectedCategory;
    }
    public List<Book> getSelectedCategoryBooks() { return selectedCategoryBooks; }

}
