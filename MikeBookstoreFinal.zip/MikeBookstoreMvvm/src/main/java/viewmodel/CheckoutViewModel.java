package viewmodel;

import business.category.Category;
import business.customer.CustomerForm;

import javax.servlet.http.HttpServletRequest;

/**
 *  This class establishes the view model that defines the variables
 *  and methods used to select and display objects in the dynamic Checkout page
 *  it extends the default BaseViewModel
 */
public class CheckoutViewModel extends BaseViewModel {

    // The Checkout page needs access to these variables
    private Category selectedCategory;
    private CustomerForm customerForm;
    private Boolean hasTransactionError;
    private Boolean hasValidationError;

    /**
     * Constructor method for the Checkout page
     * @param request an HttpServletRequest object
     */
    public CheckoutViewModel(HttpServletRequest request) {
        super(request);

        // this line prevents the nav bar from highlighting the home icon as the selected category
        this.selectedCategory = new Category(3, "checkout");

        CustomerForm sessionForm = (CustomerForm) session.getAttribute("customerForm");
        customerForm = (sessionForm == null) ? new CustomerForm() : sessionForm;

        hasValidationError = (Boolean) session.getAttribute("validationError");
        session.setAttribute("validationError", null);

        hasTransactionError = (Boolean) session.getAttribute("transactionError");
        request.getSession().setAttribute("transactionError", null);
    }

    /**
     * Getter method that returns the selected Category
     * @return a Category object
     */
    public Category getSelectedCategory() {
        return selectedCategory;
    }

    /**
     * Getter method that returns the page's CustomerForm
     * @return a CustomerForm object
     */
    public CustomerForm getCustomerForm() {
        return customerForm;
    }

    /**
     * Getter method that returns the presence of validation errors in the CustomerForm
     * @return a boolean variable representing the presence of validation errors
     */
    public boolean getHasValidationError() {
        return hasValidationError != null && hasValidationError;
    }

    /**
     * Getter method that returns the presence of transaction errors during the order process
     * @return a boolean variable representing the presence of transaction errors
     */
    public boolean getHasTransactionError() {
        return hasTransactionError != null && hasTransactionError;
    }
}
