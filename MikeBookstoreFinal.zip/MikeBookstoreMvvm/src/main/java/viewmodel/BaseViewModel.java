package viewmodel;

import business.ApplicationContext;
import business.book.BookDao;
import business.cart.ShoppingCart;
import business.category.Category;
import business.category.CategoryDao;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 *  This class establishes the default view model that defines the variables
 *  and methods used to select and display objects in the dynamic bookstore pages
 */
public class BaseViewModel {

    // We're moving the initialization parameters to the view model
    private static final String SITE_IMAGE_PATH = "images/site/";
    private static final String BOOK_IMAGE_PATH = "images/books/";

    // Every view model knows the request and session
    protected HttpServletRequest request;
    protected HttpSession session;

    // Every view model needs access to the category and book Daos
    protected CategoryDao categoryDao = ApplicationContext.INSTANCE.getCategoryDao();
    protected BookDao bookDao = ApplicationContext.INSTANCE.getBookDao();

    // The header needs to know the categories on all pages
    private List<Category> categories;

    // The nav bar needs to know the selected category on all pages
    private Category selectedCategory;

    //The header needs to know shopping cart information
    private ShoppingCart cart;

    //Setting a surcharge value
    private int surcharge = 500;

    /**
     * This method constructs the base view model and initializes the variables
     * @param request an HttpServlet object
     */
    public BaseViewModel(HttpServletRequest request) {
        this.request = request;
        this.session = request.getSession(true);
        this.categories = initCategories();
        this.selectedCategory = initSelectedCategory();
        this.cart = initCart();
    }

    /**
     * This method initializes the list of available book categories for the bookstore
     * by drawing the information from the store's SQL database
     * @return a List of available Categories
     */
    private List<Category> initCategories() {
        List<Category> result = (List<Category>) request.getServletContext().getAttribute("categories");
        if (result == null) {
            result = categoryDao.findAll();
            request.getServletContext().setAttribute("categories", result);
        }
        return result;
    }

    /**
     * This method initializes the user's ShoppingCart, creating a new
     * object if one does not currently exist
     * @return a ShoppingCart object
     */
    private ShoppingCart initCart() {
        ShoppingCart result = (ShoppingCart) request.getSession().getAttribute("cart");
        if (result == null) {
            result = new ShoppingCart();
            request.getSession().setAttribute("cart", result);
        }
        result.setSurcharge(surcharge);
        return result;
    }

    /**
     * This method initializes the user's selected Category to the home page
     * subsequent view models will adjust this variable as appropriate
     * @return a Category object
     */
    private Category initSelectedCategory() {
        return new Category(1, "home_page");
    }

    /**
     * Getter method that returns the user's current SelectedCategory
     * @return a Category object
     */
    public Category getSelectedCategory() {
        return selectedCategory;
    }

    /**
     * Getter method that returns the current image path from which to retrieve
     * site images
     * @return a String variable representing the image path
     */
    public String getSiteImagePath() { return SITE_IMAGE_PATH; }

    /**
     * Getter method that returns the current image path from which to retrieve
     * book images
     * @return a String variable representing the image path
     */
    public String getBookImagePath() { return BOOK_IMAGE_PATH; }

    /**
     * Getter method that returns a list of the available Categories on the
     * bookstore site
     * @return a List of Category objects
     */
    public List<Category> getCategories() { return categories; }

    /**
     * Getter method that returns the user's ShoppingCart
     * @return a ShoppingCart object
     */
    public ShoppingCart getCart() {return cart;}

    /**
     * Getter method that returns the surcharge applied to bookstore purchases
     * @return an int variable representing the surcharge
     */
    public int getSurcharge() { return surcharge;}
}
