package viewmodel;

import business.cart.ShoppingCart;
import business.cart.ShoppingCartItem;
import business.category.Category;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 *  This class establishes the view model that defines the variables
 *  and methods used to select and display objects in the dynamic Cart page
 *  it extends the default BaseViewModel
 */
public class CartViewModel extends BaseViewModel {

    // The page needs to know the user's selected category
    private Category selectedCategory;

    /**
     * Constructor method for the Cart page that builds upon the default BaseViewModel
     * @param request
     */
    public CartViewModel (HttpServletRequest request) {

        super(request);

        // this line prevents the nav bar from highlighting the home icon as the selected category
        // based on the initialization process in the BaseViewModel
        this.selectedCategory = new Category(2, "cart");
    }

    /**
     * Getter method that returns the user's selected Category
     * @return a Category object representing the user's selected Category
     */
    public Category getSelectedCategory() {
        return selectedCategory;
    }

}

