package viewmodel;

import business.book.Book;
import business.category.Category;

import javax.servlet.http.HttpServletRequest;
import java.util.Random;

/**
 *  This class establishes the view model that defines the variables
 *  and methods used to select and display objects in the dynamic Home page
 *  it extends the default BaseViewModel
 */
public class HomepageViewModel extends BaseViewModel{

    // The Home page needs access to the Books that are selected at random for display
    private Book bookOne;
    private Book bookTwo;
    private Book bookThree;

    /**
     * Constructor method that selects three random books to display on the Home page
     * @param request an HttpServletRequest object
     */
    public HomepageViewModel (HttpServletRequest request) {

        super(request);
        int numBooks = getNumBooks(categoryDao.findAll().size());
        this.bookOne = getRandomBook(numBooks);
        this.bookTwo = getRandomBook(numBooks);
        // while loop ensures that the second random book doesn't match the first
        while (bookTwo.equals(bookOne)) {
            bookTwo = getRandomBook(numBooks);
        }
        this.bookThree = getRandomBook(numBooks);
        // while loop ensures that the third random book does not match the first two Books
        while (bookThree.equals(bookOne) || bookThree.equals(bookTwo)) {
            bookThree = getRandomBook(numBooks);
        }
    }

    /**
     * Helper method that returns the number of Books contained in the bookstore's database
     * @param i an int variable representing the number of Categories in the bookstore database
     * @return an int variable representing the number of Books in the database
     */
    private int getNumBooks (int i) {
        int numBooks = 0;
        int counter = 0;
        while (counter < i) {
            numBooks = numBooks + bookDao.findByCategoryId(1001+counter).size();
            counter++;
        }
        return numBooks;
    }

    /**
     * Helper method that selects a Book at random from the bookstore database by bookId
     * @param i an int variable representing the number of Books in the database
     * @return a Book object selected at random from the database
     */
    private Book getRandomBook(int i) {
        Random r = new Random();
        long randomBookId = (long) r.nextInt(((1000+i) - 1001) + 1) + 1001;
        return bookDao.findByBookId(randomBookId);
    }

    /**
     * Getter method that returns the first Book object selected at random
     * @return a Book object
     */
    public Book getBookOne() { return bookOne;}

    /**
     * Getter method that returns the second Book object selected at random
     * @return a Book object
     */
    public Book getBookTwo() { return bookTwo;}

    /**
     * Getter method that returns the third Book object selected at random
     * @return a Book object
     */
    public Book getBookThree() { return bookThree;}

    /**
     * Getter method that returns the Category in which the first random Book is contained
     * @return a Category object
     */
    public Category getBookOneCategory() { return categoryDao.findByCategoryId(bookOne.getCategoryId());}

    /**
     * Getter method that returns the Category in which the second random Book is contained
     * @return a Category object
     */
    public Category getBookTwoCategory() { return categoryDao.findByCategoryId(bookTwo.getCategoryId());}

    /**
     * Getter method that returns the Category in which the third random Book is contained
     * @return a Category object
     */
    public Category getBookThreeCategory() { return categoryDao.findByCategoryId(bookThree.getCategoryId());}
}