package controller;

import business.order.OrderDetails;
import viewmodel.ConfirmationViewModel;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * The Confirmation Servlet class is used to define Post and Get actions for the bookstore's confirmation page
 */
@WebServlet(name = "ConfirmationServlet", urlPatterns={"/confirmation"} )
public class ConfirmationServlet extends BookstoreServlet {

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // resolves issue with user manually entering /confirmation url path without going through checkout
        // redirects the user to the cart page where they will encounter an 'empty cart' message
        HttpSession session = request.getSession();
        OrderDetails orderDetails = (OrderDetails) session.getAttribute("orderDetails");
        try {
            if (orderDetails.getLineItems().isEmpty()) {
                response.sendRedirect(request.getContextPath() + "/cart");
                return;
            }
        } catch (NullPointerException e) {
            response.sendRedirect(request.getContextPath() + "/cart");
            return;
        }

        request.setAttribute("p", new ConfirmationViewModel(request));

        forwardToJsp(request, response,"/confirmation");
    }
}
