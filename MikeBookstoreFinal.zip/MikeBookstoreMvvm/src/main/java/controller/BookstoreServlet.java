package controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "Bookstore",
        loadOnStartup = 1)

/**
 * The BookstoreServlet class is the default Servlet for the bookstore
 * web application and its primary purpose is to define basic forwarding
 * method that allows the user to navigate between pages
 */
public class BookstoreServlet extends HttpServlet {

    // Forwards the request to [userPath].jsp

    /**
     * Default method called by other Servlets to navigate the website
     * @param request An HttpServletRequest object
     * @param response An HttpServletResponse object
     * @param userPath A String variable representing the name of the page to navigate to
     */
    protected void forwardToJsp(HttpServletRequest request,
                                HttpServletResponse response, String userPath) {
        String url = "/WEB-INF/jsp" + userPath + ".jsp";
        try {
            request.getRequestDispatcher(url).forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}

