package controller;

import business.ApplicationContext;
import business.book.Book;
import business.book.BookDao;
import business.cart.ShoppingCart;
import viewmodel.CartViewModel;
import viewmodel.CategoryViewModel;

import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * The CartServlet class is used to define Post and Get actions for the bookstore's cart page
 */
@WebServlet(name = "CartServlet", urlPatterns={"/cart"} )
@ServletSecurity(@HttpConstraint(transportGuarantee = ServletSecurity.TransportGuarantee.CONFIDENTIAL))
public class CartServlet extends BookstoreServlet {

    /**
     * Handles the HTTP <code>POST</code> method and is primarily utilized to add, adjust, and remove
     * items from the user's shopping cart
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        // The following if/else if statements identify the user's desired cart action and
        // make the appropriate adjustments to the composition of cart contents
        if ("add".equals(action)) {
            ShoppingCart cart = (ShoppingCart) request.getSession().getAttribute("cart");
            String bookIdText = request.getParameter("bookId");
            long bookId = Long.parseLong(bookIdText);
            Book book = ApplicationContext.INSTANCE.getBookDao().findByBookId(bookId);
            cart.addItem(book);
            boolean isAjaxRequest =
                    "XMLHttpRequest".equalsIgnoreCase(request.getHeader("X-Requested-With"));
            if (isAjaxRequest) {
                String jsonString = "{\"cartCount\": " + cart.getNumberOfItems() + "}";
                response.setContentType("application/json");
                response.getWriter().write(jsonString);
                response.flushBuffer();
                return;
            }
            response.sendRedirect(request.getContextPath() + "/category?category=" + request.getParameter("category"));
        }
        else if ("increment".equals(action)){
            ShoppingCart cart = (ShoppingCart) request.getSession().getAttribute("cart");
            String bookIdText = request.getParameter("bookId");
            long bookId = Long.parseLong(bookIdText);
            Book book = ApplicationContext.INSTANCE.getBookDao().findByBookId(bookId);
            cart.increment(book);
            response.sendRedirect(request.getContextPath() + "/cart");
        }
        else if ("decrement".equals(action)) {
            ShoppingCart cart = (ShoppingCart) request.getSession().getAttribute("cart");
            String bookIdText = request.getParameter("bookId");
            long bookId = Long.parseLong(bookIdText);
            Book book = ApplicationContext.INSTANCE.getBookDao().findByBookId(bookId);
            cart.decrement(book);
            response.sendRedirect(request.getContextPath() + "/cart");
        }
        else if ("clear".equals(action)) {
            ShoppingCart cart = (ShoppingCart) request.getSession().getAttribute("cart");
            cart.clear();
            response.sendRedirect(request.getContextPath() + "/cart");
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setAttribute("p", new CartViewModel(request));

        forwardToJsp(request, response,"/cart");
    }
}
