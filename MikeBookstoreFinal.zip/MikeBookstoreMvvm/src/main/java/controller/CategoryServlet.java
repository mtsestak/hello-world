package controller;

import viewmodel.CategoryViewModel;

import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * The CategoryServlet class is used to define Post and Get actions for the bookstore's category pages
 */
@WebServlet(name = "CategoryServlet", urlPatterns={"/category"} )
@ServletSecurity(@HttpConstraint(transportGuarantee = ServletSecurity.TransportGuarantee.CONFIDENTIAL))
public class CategoryServlet extends BookstoreServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        if (request.getParameter("category")== null) {
            response.sendRedirect(request.getContextPath() + "/category?category=" +
                    request.getSession().getAttribute("selectedCategory"));
        }
        else {
            request.setAttribute("p", new CategoryViewModel(request));

            request.getSession().setAttribute("selectedCategory", request.getParameter("category"));

            forwardToJsp(request, response, "/category");
        }
    }
}
